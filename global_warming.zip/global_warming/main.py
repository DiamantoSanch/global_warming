import discord
from discord.ext import commands
import os
from model import get_class
from googletrans import Translator, constants
from pprint import pprint
from random import choice
from info import facts


description = 'just description'

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', description=description, intents=intents)

translator = Translator()

@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user} (ID: {bot.user.id})\n----------')

@bot.command()
async def hello(ctx):
    await ctx.send('Привет! Вот список моих команд:\n\n!K/C/F - перевести температуру из Келивина/Цельсия/Фаренгейта в другие шкалы\n\n!quiz - пройти викторину о глобальном потеплении\n\n!sortgarbage - определяет, какой тип мусора на фото, и в какой бак его следует положить')

@bot.command()
async def K(ctx, degree):
    await ctx.send(f'{float(degree)} градусов Кельвина это:\n\n{round(float(degree)-273.15, 2)} градусов Цельсия\n{round((float(degree)-273.15)*1.8 + 32, 2)} градусов Фаренгейта')

@bot.command()
async def C(ctx, degree):
    await ctx.send(f'{float(degree)} градусов Цельсия это:\n\n{round(float(degree)+273.15, 2)} градусов Кельвина\n{round(float(degree)*1.8 + 32, 2)} градусов Фаренгейта')

@bot.command()
async def F(ctx, degree):
    await ctx.send(f'{float(degree)} градусов Фаренгейта это:\n\n{round((float(degree)-32)/1.8 + 273.15, 2)} градусов Кельвина\n{round((float(degree)-32)/1.8, 2)} градусов Цельсия')


@bot.command()
async def quiz(ctx):
    await ctx.send('https://diamantosanch.pythonanywhere.com/ - ссылка на небольшую викторину')

@bot.command()
async def sortgarbage(ctx):
    if ctx.message.attachments:
        for attachment in ctx.message.attachments:
            if attachment.filename.endswith(".jpg") or attachment.filename.endswith(".jpeg") or attachment.filename.endswith(".png"):
                file_name = f'D:\Other\{attachment.filename}'
                await attachment.save(file_name)
                msg = await ctx.send("Ваше фото обрабатывается...")
                answer, percent = get_class('converted_keras/keras_model.h5', file_name, 'converted_keras/labels.txt')
                translated_answer = answer#translator.translate(answer, dest='ru').text
                await msg.delete()
                await ctx.send(f"Скорее всего это {translated_answer} с точностью {percent}. Положите это в мусорный бак для {translated_answer}.")
                os.remove(file_name)
            else:
                await ctx.send("Файл должен быть поддерживаемого формата: .jpg, .jpeg or .png")
                return
    else:
        await ctx.send("Вам нужно прикрепить фото к сообщению")

@bot.command()
async def info(ctx):
    await ctx.send(choice(facts))




bot.run("MTE0NDk2MDIwNjM1NTMwMDM4Mg.G0E9yL.5KNomwUhwuxESPXZyZQMGYoVcFE0nbbUaTfiLo")
