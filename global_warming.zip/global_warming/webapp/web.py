from flask import Flask, render_template
from descriptions import *

app = Flask(__name__)

@app.route('/')
def main():
    return render_template('1main.html')

@app.route('/<fa>')
def first_question(fa):
    return render_template('2plants.html', fa=fa)

@app.route('/<fa>/<sa>')
def second_question(fa, sa):
    return render_template('3oxygen.html', fa=fa, sa=sa)

@app.route('/<fa>/<sa>/<ta>')
def third_question(fa, sa, ta):
    return render_template('4animals.html', fa=fa, sa=sa, ta=ta)

@app.route('/<fa>/<sa>/<ta>/<foa>')
def fourth_question(fa, sa, ta, foa):
    return render_template('5food.html', fa=fa, sa=sa, ta=ta, foa=foa)

@app.route('/<fa>/<sa>/<ta>/<foa>/<fia>')
def fifth_question(fa, sa, ta, foa, fia):
    return render_template('6gas.html', fa=fa, sa=sa, ta=ta, foa=foa, fia=fia)

@app.route('/<fa>/<sa>/<ta>/<foa>/<fia>/<sia>')
def sixth_question(fa, sa, ta, foa, fia, sia):
    return render_template('7atmosphere.html', fa=fa, sa=sa, ta=ta, foa=foa, fia=fia, sia=sia)

@app.route('/<fa>/<sa>/<ta>/<foa>/<fia>/<sia>/<sea>')
def seventh_question(fa, sa, ta, foa, fia, sia, sea):
    return render_template('8ozon.html', fa=fa, sa=sa, ta=ta, foa=foa, fia=fia, sia=sia, sea=sea)

@app.route('/<fa>/<sa>/<ta>/<foa>/<fia>/<sia>/<sea>/<ea>')
def eighth_question(fa, sa, ta, foa, fia, sia, sea, ea):
    return render_template('9acidrain.html', fa=fa, sa=sa, ta=ta, foa=foa, fia=fia, sia=sia, sea=sea, ea=ea)

@app.route('/<fa>/<sa>/<ta>/<foa>/<fia>/<sia>/<sea>/<ea>/<na>')
def ninth_question(fa, sa, ta, foa, fia, sia, sea, ea, na):
    return render_template('10smog.html', fa=fa, sa=sa, ta=ta, foa=foa, fia=fia, sia=sia, sea=sea, ea=ea, na=na)

@app.route('/<fa>/<sa>/<ta>/<foa>/<fia>/<sia>/<sea>/<ea>/<na>/<tea>')
def tenth_question(fa, sa, ta, foa, fia, sia, sea, ea, na, tea):
    return render_template('endpage.html', results=count_points(fa, sa, ta, foa, fia, sia, sea, ea, na, tea))

def count_points(first, second, third, fourth, fifth, sixth, seventh, eighth, ninth, tenth):
    points = 0
    if first == '2':
        points += 1
    if second == '2':
        points += 1
    if third == '3':
        points += 1
    if fourth == '2':
        points += 1
    if fifth == '2':
        points += 1
    if sixth == '1':
        points += 1
    if seventh == '1':
        points += 1
    if eighth == '3':
        points += 1
    if ninth == '3':
        points += 1
    if tenth == '3':
        points += 1
    print('your points:', points)

    results = {'points': points, 'ending': '', 'description': ''}
    if points == 0 or points > 4:
        results['ending'] = 'ов'
    elif points == 1:
        results['ending'] = ''
    else:
        results['ending'] = 'а'

    if points < 2:
        results['description'] = bad_description
    elif points < 6:
        results['description'] = usual_description
    elif points < 9:
        results['description'] = good_description
    else:
        results['description'] = best_description
    return results

app.run(debug=True)